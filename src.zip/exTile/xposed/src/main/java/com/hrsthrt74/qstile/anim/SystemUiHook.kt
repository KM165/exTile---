package com.hrsthrt74.qstile.anim

import android.os.Build
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * exTile 动画模块 —— LSPosed 入口（HyperOS 4 适配版）。
 *
 * ## HyperOS 4 控制中心架构（逆向 miui.systemui.plugin 18.3.2.22.0 得出）
 * - 控制中心磁贴不在 SystemUI 宿主 APK 里，而在独立插件 APK（包名
 *   `miui.systemui.plugin`）中，运行时由独立 ClassLoader 动态加载；
 * - 主面板磁贴列表是 RecyclerView，Adapter 为
 *   `miui.systemui.controlcenter.panel.main.recyclerview.MainPanelAdapter`，
 *   数据控制器为 `miui.systemui.controlcenter.panel.main.qs.QSListController`
 *   （磁贴列表变化入口：onTilesChanged(List) → MainPanelContentDistributor
 *   → MainPanelAdapter.notifyChanged(ZZ)）。
 *
 * ## 没有动画的根本原因
 * `MainPanelAdapter.notifyChanged(boolean, boolean)` 内部实现：
 *   distributeContent() 更新数据 → DiffUtil.calculateDiff() 计算精确差异 →
 *   DiffResult.dispatchUpdatesTo() 分发带过渡动画的 item 通知 →
 *   **最后强制调用 notifyDataSetChanged()，把前面分发的全部动画抹掉**（全量无动画刷新）。
 *
 * ## 本模块方案（最小干预，两层）
 * 第一层：在 notifyChanged(ZZ) 执行期间拦截「MainPanelAdapter 对 notifyDataSetChanged
 * 的调用」，跳过那句强制全量刷新，让系统自己的 DiffUtil 过渡动画（增/删/移动平滑过渡）
 * 生效。磁贴开关、面板展开等其它刷新路径不受任何影响。
 *
 * 第二层（动画“时有时无”的根因）：MainPanelContentDistributor 在控制中心
 * onStart()/onStop() 时都调用 suppressItemAnimator(true)，把
 * ControlCenterItemAnimator.suppressAnimation 置为 true（animateAdd/Change/Move/Remove
 * 与 runPendingAnimations 全部短路，磁贴动画彻底关闭）；只有「非编辑模式刷新」
 * handleNotifyChanged() 才会传 false 解除。因此从编辑磁贴返回后有动画、控制中心
 * 一收起（onStop）动画又消失。全插件传 true 的调用点仅 onStart/onStop 两处，故 hook
 * suppressItemAnimator(Z) 把 true 强制改为 false——动画永不关闭，收起/展开控制中心
 * 也不再有通知产生动画的副作用（初始布局不走 item animator）。
 *
 * ## 插件 ClassLoader 问题（首版无效的原因）
 * 插件类无法通过 lpparam.classLoader（宿主）找到——双亲委派方向相反。
 * 因此 hook 基类 ClassLoader.loadClass(String, boolean) 观察 MainPanelAdapter
 * 类的加载时机，拿到插件 ClassLoader 中的类对象后再实施 hook；
 * MainPanelContentDistributor 与 Adapter 同属一个插件 dex，直接用该 ClassLoader 加载。
 */
class SystemUiHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "exTileAnim"

        /** 仅作用于 SystemUI 进程 */
        private const val SYSTEMUI_PACKAGE = "com.android.systemui"

        /** HyperOS 4 控制中心主面板磁贴 Adapter（位于 miui.systemui.plugin 插件内） */
        private const val MAIN_PANEL_ADAPTER =
            "miui.systemui.controlcenter.panel.main.recyclerview.MainPanelAdapter"

        /** 控制中心内容分发器：onStart/onStop 在此调用 suppressItemAnimator(true) 抑制动画 */
        private const val MAIN_PANEL_DISTRIBUTOR =
            "miui.systemui.controlcenter.panel.main.MainPanelContentDistributor"

        /** MainPanelAdapter 的 androidx 基类（notifyDataSetChanged 的声明处） */
        private const val ADAPTER_BASE_NAME = "androidx.recyclerview.widget.RecyclerView\$Adapter"

        private fun log(message: String) {
            XposedBridge.log("[$TAG] $message")
        }
    }

    /**
     * notifyChanged(ZZ) 执行期间的线程内重入标志。
     * 用 ThreadLocal 保证多线程下互不干扰（正常应在 SystemUI 主线程）。
     */
    private val inNotifyChanged = ThreadLocal.withInitial { false }

    /** 类加载监视 hook 的撤销句柄（成员变量，避免初始化自引用问题） */
    private var classLoadUnhook: XC_MethodHook.Unhook? = null

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // 模块作用域只勾选 SystemUI；这里再校验一次，防止被误加载到其他进程
        if (lpparam.packageName != SYSTEMUI_PACKAGE) return

        log("模块已加载：Android ${Build.VERSION.SDK_INT}（${Build.MANUFACTURER} ${Build.MODEL}）")

        // HyperOS 4 的控制中心是独立插件（miui.systemui.plugin），由独立 ClassLoader 加载，
        // 其类无法通过 lpparam.classLoader（宿主）找到；先观察插件类的加载时机
        waitForAdapterClass()
    }

    // ------------------------------------------------------------------
    // 第一步：等待插件类加载
    // ------------------------------------------------------------------

    /**
     * hook 基类 ClassLoader.loadClass(String, boolean)（所有 ClassLoader 的类加载入口，
     * ART 解析非 boot 类时同样经过此处），等待 MainPanelAdapter 被插件 ClassLoader 加载。
     * 命中后立即撤销本 hook，避免长期影响类加载性能。
     */
    private fun waitForAdapterClass() {
        classLoadUnhook = XposedHelpers.findAndHookMethod(
            ClassLoader::class.java, "loadClass",
            String::class.java, Boolean::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (param.args[0] != MAIN_PANEL_ADAPTER) return
                    val clazz = param.result as? Class<*> ?: return
                    // 立即撤销类加载监视，后续 hook 一次性完成
                    runCatching { classLoadUnhook?.unhook() }
                    log("MainPanelAdapter 已由插件 ClassLoader 加载：${clazz.classLoader}")
                    hookAdapter(clazz)
                }
            })
        log("已挂载类加载监视，等待 $MAIN_PANEL_ADAPTER")
    }

    // ------------------------------------------------------------------
    // 第二步：对磁贴 Adapter 实施 hook
    // ------------------------------------------------------------------

    private fun hookAdapter(adapterClass: Class<*>) {
        hookNotifyChanged(adapterClass)
        hookNotifyDataSetChanged(adapterClass)
        hookSuppressItemAnimator(adapterClass.classLoader)
    }

    /**
     * hook MainPanelAdapter.notifyChanged(boolean, boolean)。
     *
     * 磁贴列表变化（sysui_qs_tiles 变更 → onTilesChanged → 分发）的核心处理方法，
     * 内部执行：distributeContent 更新数据 → DiffUtil 计算差异 → dispatchUpdatesTo
     * 分发带动画通知 → 【强制 notifyDataSetChanged 抹掉动画】。
     * 在此设置线程内标志，配合 [hookNotifyDataSetChanged] 跳过最后那句全量刷新。
     */
    private fun hookNotifyChanged(adapterClass: Class<*>) {
        runCatching {
            XposedHelpers.findAndHookMethod(
                adapterClass, "notifyChanged",
                Boolean::class.javaPrimitiveType, Boolean::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        inNotifyChanged.set(true)
                        log("notifyChanged(${param.args[0]}, ${param.args[1]})："
                            + "磁贴列表变化，拦截末尾的强制全量刷新以保留 DiffUtil 过渡动画")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        // 无论是否抛出异常都要清除标志，避免标志泄漏影响后续刷新
                        inNotifyChanged.set(false)
                    }
                })
            log("已 hook MainPanelAdapter.notifyChanged(ZZ)")
        }.onFailure {
            log("hook notifyChanged(ZZ) 失败：${it.javaClass.simpleName}: ${it.message}")
        }
    }

    /**
     * hook androidx RecyclerView$Adapter.notifyDataSetChanged
     * （MainPanelAdapter 的父类声明处，MainPanelAdapter 未覆写）。
     *
     * 仅在 [inNotifyChanged] 为真（正处于 notifyChanged(ZZ) 执行期间）、
     * 且 thisObject 正是 MainPanelAdapter 时跳过原调用——
     * DiffUtil 已 dispatchUpdatesTo 的动画通知得以保留，其余调用路径不受影响。
     */
    private fun hookNotifyDataSetChanged(adapterClass: Class<*>) {
        runCatching {
            // 沿父类链找到 RecyclerView$Adapter 的真实运行时类
            // （MainPanelAdapter 直接继承它；写成循环以兼容未来出现中间基类的情况）
            var base: Class<*>? = adapterClass.superclass
            while (base != null && base.name != ADAPTER_BASE_NAME) {
                base = base.superclass
            }
            if (base == null) {
                log("未找到父类 $ADAPTER_BASE_NAME，无法拦截 notifyDataSetChanged")
                return
            }

            XposedBridge.hookAllMethods(base, "notifyDataSetChanged", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (inNotifyChanged.get() && param.thisObject?.javaClass == adapterClass) {
                        // 跳过原方法：保留 dispatchUpdatesTo 已分发的 Diff 动画
                        param.result = null
                        log("已跳过强制全量刷新，DiffUtil 过渡动画生效")
                    }
                }
            })
            log("已 hook ${base.name}.notifyDataSetChanged")
        }.onFailure {
            log("hook notifyDataSetChanged 失败：${it.javaClass.simpleName}: ${it.message}")
        }
    }

    /**
     * hook MainPanelContentDistributor.suppressItemAnimator(boolean)。
     *
     * ## 为什么动画「时有时无」
     * 全插件内 suppressItemAnimator(true)（关闭磁贴动画）的调用点只有两处：
     *   - onStart()：控制中心展开时
     *   - onStop() ：控制中心收起时
     * 而解除抑制（传 false）只发生在「非编辑模式的列表刷新」handleNotifyChanged()
     * 中。这正好解释了用户现象：从磁贴编辑页返回 → 触发一次非编辑刷新 → 动画开启；
     * 控制中心收起 → onStop 重新压制 → 之后再点磁贴动画全无。
     *
     * ## 处理方式
     * 把传入的 true 强制改为 false：动画永远不被关闭。传 false 的调用（系统自身
     * 解除抑制、设备控制/卡片入口的 updateItemAnimatorSuppress）不受影响。
     * 副面影响可忽略：收起时不再立即取消进行中的动画（收起后本就不可见），
     * 展开时初始布局不经过 item animator，不会凭空产生动画。
     */
    private fun hookSuppressItemAnimator(pluginClassLoader: ClassLoader) {
        runCatching {
            val distributorClass = XposedHelpers.findClass(MAIN_PANEL_DISTRIBUTOR, pluginClassLoader)
            XposedHelpers.findAndHookMethod(
                distributorClass, "suppressItemAnimator",
                Boolean::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        // 仅改写「关闭动画」的调用；开启动画的调用原样放行
                        if (param.args[0] == true) {
                            param.args[0] = false
                            log("suppressItemAnimator(true) → false：解除动画压制，磁贴过渡动画保持开启")
                        }
                    }
                })
            log("已 hook MainPanelContentDistributor.suppressItemAnimator(Z)")
        }.onFailure {
            log("hook suppressItemAnimator 失败：${it.javaClass.simpleName}: ${it.message}")
        }
    }
}
