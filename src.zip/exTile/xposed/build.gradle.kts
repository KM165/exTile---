plugins {
    // AGP 9 内置 Kotlin 支持，无需额外声明 Kotlin 插件（与 :app 保持一致）
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.hrsthrt74.qstile.anim"

    compileSdk = 37

    defaultConfig {
        // 独立 APK：与主应用（com.hrsthrt74.qstile）互不依赖，仅通过 LSPosed 框架注入 SystemUI 生效
        applicationId = "com.hrsthrt74.qstile.anim"
        minSdk = 33
        targetSdk = 36
        versionCode = 3
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            // 入口类名通过 assets/xposed_init 由框架反射加载，绝不能混淆/裁剪
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Xposed API 仅编译期引用：运行时由 LSPosed 框架在 SystemUI 进程内提供实现
    compileOnly(libs.xposed.api)
}
