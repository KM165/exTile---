package com.hrsthrt74.qstile.anim

import android.os.Build
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * exTile 动画模块 —— LSPosed 入口（HyperOS 4 适配版）。
 *
 * ## HyperOS 4 控制中心架构（逆向 miui.systemui.plugin 18.3.2.22.0 得出）
 * - 控制中心磁贴不在 SystemUI 宿主 APK 里，而在独立插件 APK（包名
 *   `miui.systemui.plugin`）中，运行时由独立 ClassLoader 动态加载；
 * - 主面板磁贴列表是 RecyclerView，Adapter 为
 *   `miui.systemui.controlcenter.panel.main.recyclerview.MainPanelAdapter`，
 *   数据控制器为 `miui.systemui.controlcenter.panel.main.qs.QSListController`
 *   （磁贴列表变化入口：onTilesChanged(List) → MainPanelContentDistributor
 *   → MainPanelAdapter.notifyChanged(ZZ)）。
 *
 * ## notifyChanged(ZZ) 的真实结构（关键，纠正早前版本的误读）
 * `MainPanelAdapter.notifyChanged(boolean, boolean)` 内部是**互斥二选一**：
 *   distributeContent() 更新数据 → 比较 style/mode →
 *   ① 生命周期就绪 && 参数 z2 && style 未变化：
 *        DiffUtil.calculateDiff().dispatchUpdatesTo(this) —— 带过渡动画；
 *   ② 否则：notifyDataSetChanged() —— 全量无动画刷新。
 * notifyDataSetChanged 不是「DiffUtil 之后追加的强制刷新」而是 else 分支，
 * 因此**绝不能跳过它**：走到该分支时它是唯一的数据同步通知，跳过会使
 * RecyclerView 与 Adapter 数据不一致，触发 "Inconsistency detected" 崩溃
 * （横屏下滑控制中心 style 必然变化 → 走 else 分支 → 旧版本因此闪退）。
 *
 * ## 没有动画的真正（且唯一）原因
 * 分支①的 DiffUtil 动画一直都在，但被动画压制盖住了：
 * MainPanelContentDistributor 在控制中心 onStart()/onStop() 时都调用
 * suppressItemAnimator(true)，把 ControlCenterItemAnimator.suppressAnimation
 * 置为 true（animateAdd/Change/Move/Remove 与 runPendingAnimations 全部短路）；
 * 只有「非编辑模式刷新」handleNotifyChanged() 才会传 false 解除——这正是
 * 「编辑磁贴返回后有动画、控制中心一收起又消失」的原因。
 * 全插件传 true 的调用点仅 onStart/onStop 两处，所以只需 hook
 * suppressItemAnimator(Z) 把 true 强制改为 false，DiffUtil 动画即可常驻，
 * 其余系统逻辑零改动。
 *
 * ## 插件 ClassLoader 问题（首版无效的原因）
 * 插件类无法通过 lpparam.classLoader（宿主）找到——双亲委派方向相反。
 * 因此 hook 基类 ClassLoader.loadClass(String, boolean) 观察 MainPanelAdapter
 * 类的加载时机，拿到插件 ClassLoader 后再实施 hook；
 * MainPanelContentDistributor 与 Adapter 同属一个插件 dex，直接用该
 * ClassLoader 加载即可。
 */
class SystemUiHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "exTileAnim"

        /** 仅作用于 SystemUI 进程 */
        private const val SYSTEMUI_PACKAGE = "com.android.systemui"

        /** HyperOS 4 控制中心主面板磁贴 Adapter（位于 miui.systemui.plugin 插件内） */
        private const val MAIN_PANEL_ADAPTER =
            "miui.systemui.controlcenter.panel.main.recyclerview.MainPanelAdapter"

        /** 控制中心内容分发器：onStart/onStop 在此调用 suppressItemAnimator(true) 抑制动画 */
        private const val MAIN_PANEL_DISTRIBUTOR =
            "miui.systemui.controlcenter.panel.main.MainPanelContentDistributor"

        private fun log(message: String) {
            XposedBridge.log("[$TAG] $message")
        }
    }

    /** 类加载监视 hook 的撤销句柄（成员变量，避免初始化自引用问题） */
    private var classLoadUnhook: XC_MethodHook.Unhook? = null

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // 模块作用域只勾选 SystemUI；这里再校验一次，防止被误加载到其他进程
        if (lpparam.packageName != SYSTEMUI_PACKAGE) return

        log("模块已加载：Android ${Build.VERSION.SDK_INT}（${Build.MANUFACTURER} ${Build.MODEL}）")

        // HyperOS 4 的控制中心是独立插件（miui.systemui.plugin），由独立 ClassLoader 加载，
        // 其类无法通过 lpparam.classLoader（宿主）找到；先观察插件类的加载时机
        waitForAdapterClass()
    }

    // ------------------------------------------------------------------
    // 第一步：等待插件类加载
    // ------------------------------------------------------------------

    /**
     * hook 基类 ClassLoader.loadClass(String, boolean)（所有 ClassLoader 的类加载入口，
     * ART 解析非 boot 类时同样经过此处），等待 MainPanelAdapter 被插件 ClassLoader 加载。
     * 命中后立即撤销本 hook，避免长期影响类加载性能。
     */
    private fun waitForAdapterClass() {
        classLoadUnhook = XposedHelpers.findAndHookMethod(
            ClassLoader::class.java, "loadClass",
            String::class.java, Boolean::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    if (param.args[0] != MAIN_PANEL_ADAPTER) return
                    val clazz = param.result as? Class<*> ?: return
                    // 立即撤销类加载监视，后续 hook 一次性完成
                    runCatching { classLoadUnhook?.unhook() }
                    log("MainPanelAdapter 已由插件 ClassLoader 加载：${clazz.classLoader}")
                    hookSuppressItemAnimator(clazz.classLoader)
                }
            })
        log("已挂载类加载监视，等待 $MAIN_PANEL_ADAPTER")
    }

    // ------------------------------------------------------------------
    // 第二步：解除磁贴动画压制
    // ------------------------------------------------------------------

    /**
     * hook MainPanelContentDistributor.suppressItemAnimator(boolean)。
     *
     * ## 为什么动画「时有时无」
     * 全插件内 suppressItemAnimator(true)（关闭磁贴动画）的调用点只有两处：
     *   - onStart()：控制中心展开时
     *   - onStop() ：控制中心收起时
     * 而解除抑制（传 false）只发生在「非编辑模式的列表刷新」handleNotifyChanged()
     * 中。这正好解释了用户现象：从磁贴编辑页返回 → 触发一次非编辑刷新 → 动画开启；
     * 控制中心收起 → onStop 重新压制 → 之后再点磁贴动画全无。
     *
     * ## 处理方式
     * 把传入的 true 强制改为 false：动画永远不被关闭。传 false 的调用（系统自身
     * 解除抑制、设备控制/卡片入口的 updateItemAnimatorSuppress）不受影响。
     * 副面影响可忽略：收起时不再立即取消进行中的动画（收起后本就不可见），
     * 展开时初始布局不经过 item animator，不会凭空产生动画。
     */
    private fun hookSuppressItemAnimator(pluginClassLoader: ClassLoader) {
        runCatching {
            val distributorClass = XposedHelpers.findClass(MAIN_PANEL_DISTRIBUTOR, pluginClassLoader)
            XposedHelpers.findAndHookMethod(
                distributorClass, "suppressItemAnimator",
                Boolean::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        // 仅改写「关闭动画」的调用；开启动画的调用原样放行
                        if (param.args[0] == true) {
                            param.args[0] = false
                            log("suppressItemAnimator(true) → false：解除动画压制，磁贴过渡动画保持开启")
                        }
                    }
                })
            log("已 hook MainPanelContentDistributor.suppressItemAnimator(Z)")
        }.onFailure {
            log("hook suppressItemAnimator 失败：${it.javaClass.simpleName}: ${it.message}")
        }
    }
}
