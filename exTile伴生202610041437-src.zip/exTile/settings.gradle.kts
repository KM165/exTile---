pluginManagement {
    repositories {
        mavenCentral()
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://maven.aliyun.com/repository/public") }
        google()
        gradlePluginPortal()
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        mavenCentral()
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/public") }
        google()
        maven { url = uri("https://jitpack.io") }
        // Xposed 官方 Maven 仓库：de.robv.android.xposed:api（Maven Central 拉取失败时兜底）
        maven { url = uri("https://api.xposed.info/") }
    }
}

rootProject.name = "exTile"
include(":app")
// LSPosed 模块：hook SystemUI 为磁贴布局切换挂载系统原生过渡动画（独立 APK，与主应用互不依赖）
include(":xposed")
