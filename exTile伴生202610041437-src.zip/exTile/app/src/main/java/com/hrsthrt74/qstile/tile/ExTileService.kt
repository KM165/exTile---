package com.hrsthrt74.qstile.tile

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import com.hrsthrt74.qstile.R
import com.hrsthrt74.qstile.data.ConfigRepository
import com.hrsthrt74.qstile.data.StatsRepository
import com.hrsthrt74.qstile.shizuku.SecureSettingsHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ExTileService : TileService() {
    companion object {
        private const val TAG = "ExTileService"
    }

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()

        scope.launch {
            try {
                // OOBE 未完成时不执行任何操作：
                // 首次使用引导期间用户可能已把磁贴添加到面板但尚未完成配置导入，
                // 此时点击磁贴会以默认配置写 sysui_qs_tiles，覆盖用户当前的系统布局。
                // 「重新运行引导」期间（标志被重置为 false）同样拦截，保持行为一致。
                val oobeCompleted = ConfigRepository.getOobeCompletedFlow(this@ExTileService).first()
                if (!oobeCompleted) {
                    Log.d(TAG, "OOBE not completed, ignore tile click")
                    return@launch
                }

                val config = ConfigRepository.getConfig(this@ExTileService)
                // onClick = 切换：当前展开则收起，当前收起则展开
                val newIsExpanded = !config.isExpanded
                applyLayout(newIsExpanded, config)
                updateTileState()
            } catch (e: Exception) {
                Log.e(TAG, "onClick failed", e)
            }
        }
    }

    /**
     * 用户收起 QS 快速设置面板时系统回调所有已注册磁贴服务。
     * 利用此公开 API（零权限）实现「收起面板时自动收起」功能：
     * 若开关开启 且 磁贴当前处于展开布局，则自动执行一次收起操作。
     * 幂等：若已是收起状态则跳过，避免重复写 sysui_qs_tiles。
     */
    override fun onStopListening() {
        super.onStopListening()
        scope.launch {
            try {
                val autoCollapse = ConfigRepository.getAutoCollapseOnClose(this@ExTileService)
                if (!autoCollapse) return@launch

                val config = ConfigRepository.getConfig(this@ExTileService)
                // 仅在展开状态下触发收起；已是收起状态则跳过（幂等）
                if (!config.isExpanded) return@launch

                Log.d(TAG, "Auto-collapsing on QS panel close")
                applyLayout(newIsExpanded = false, config)
                updateTileState()
            } catch (e: Exception) {
                Log.e(TAG, "onStopListening auto-collapse failed", e)
            }
        }
    }

    /**
     * 将磁贴布局切换到指定状态并同步所有关联设置。
     * onClick（手动切换）和 onStopListening（自动收起）共用此函数，
     * 避免重复代码。执行顺序：
     * 1. 写 sysui_qs_tiles（目标布局）
     * 2. 保存 isExpanded 标志
     * 3. 记录统计（展开/收起）
     * 4. 按开关同步无字模式 / 融合设备中心
     *
     * @param newIsExpanded 目标展开状态：true = 展开，false = 收起
     * @param config 当前配置（用于获取展开/收起磁贴列表，避免重复读取）
     */
    private suspend fun applyLayout(newIsExpanded: Boolean, config: com.hrsthrt74.qstile.data.TileConfig) {
        val tilesToSet = if (newIsExpanded) {
            config.expandedTiles
        } else {
            config.collapsedTiles
        }

        val success = SecureSettingsHelper.setCurrentTiles(this@ExTileService, tilesToSet)

        if (success) {
            ConfigRepository.saveIsExpanded(this@ExTileService, newIsExpanded)
            Log.d(TAG, "Layout applied: ${if (newIsExpanded) "expanded" else "collapsed"}")

            // 记录统计：仅统计布局切换成功的情况（失败不算）
            if (newIsExpanded) {
                StatsRepository.recordExpand(this@ExTileService)
            } else {
                StatsRepository.recordCollapse(this@ExTileService)
            }

            // 「展开收起同时控制无字模式」：开启后，磁贴切换布局时同步 wordless_mode
            // 展开 → wordless_mode=0（显示文字），收起 → wordless_mode=1（无字模式）
            if (ConfigRepository.getWordlessModeSync(this@ExTileService)) {
                SecureSettingsHelper.putSecureSetting(
                    this@ExTileService,
                    "wordless_mode",
                    if (newIsExpanded) "0" else "1"
                )
            }

            // 「展开收起同时控制融合设备中心」：开启后，磁贴切换布局时同步 smart_device_control
            // 展开 → smart_device_control=1，收起 → smart_device_control=0（与无字模式相反）
            if (ConfigRepository.getSmartDeviceControlSync(this@ExTileService)) {
                SecureSettingsHelper.putSecureSetting(
                    this@ExTileService,
                    "smart_device_control",
                    if (newIsExpanded) "1" else "0"
                )
            }
        } else {
            Log.e(TAG, "Failed to set sysui_qs_tiles")
        }
    }

    private fun updateTileState() {
        scope.launch {
            try {
                val config = ConfigRepository.getConfig(this@ExTileService)
                val tile = qsTile ?: return@launch

                tile.state = if (config.isExpanded) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                // 磁贴名字：读取预设选项与自定义名字，结合当前展开状态计算显示文案
                val labelPreset = ConfigRepository.getTileLabelPreset(this@ExTileService)
                val customLabel = ConfigRepository.getTileLabelCustom(this@ExTileService)
                tile.label = ConfigRepository.TileLabelPreset.resolveLabel(
                    preset = labelPreset,
                    isExpanded = config.isExpanded,
                    customName = customLabel
                )

                // 磁贴图标：读取预设选项，映射为对应 drawable 资源；默认时用 ic_tile 显式设置。
                // TileService 在整个生命周期内复用同一个 Tile 对象：若默认分支不设置 icon，
                // 会残留上一次的非默认图标，导致切回默认后不刷新；而显式 setIcon(null) 在
                // 部分系统上 SystemUI 不回落默认图标，反而渲染灰色占位。故统一显式设置。
                val tileIconRes = ConfigRepository.TileIcon.iconRes(
                    ConfigRepository.getTileIcon(this@ExTileService)
                ) ?: R.drawable.ic_tile
                tile.icon = Icon.createWithResource(this@ExTileService, tileIconRes)

                tile.updateTile()
            } catch (e: Exception) {
                Log.e(TAG, "updateTileState failed", e)
            }
        }
    }
}
